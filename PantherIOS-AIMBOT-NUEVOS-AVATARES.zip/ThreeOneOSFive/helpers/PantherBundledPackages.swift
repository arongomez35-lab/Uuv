import Foundation

// Installs the three bundled .3105 avatar packages once, using their native format.
enum PantherBundledPackages {
    private static let packageNames = ["Avatar Cabeza", "Avatar Cuello", "Avatar Pecho"]

    static func installIfNeeded() {
        for name in packageNames {
            do {
                guard let url = Bundle.main.url(forResource: name, withExtension: "3105") else {
                    log("patch: missing bundled avatar package \(name)")
                    continue
                }
                let data = try Data(contentsOf: url)
                let summary = try PatchPackageCodec.inspect(data)
                let existing = PatchProjectLibrary.load().first { $0.id == summary.packageID }
                if existing != nil { continue }
                let decoded = try PatchPackageCodec.decode(data, password: nil)
                try PatchProjectLibrary.installImportedPackage(
                    data: data,
                    decoded: decoded,
                    summary: summary,
                    existingURL: nil
                )
            } catch {
                log("patch: avatar package installation failed for \(name): \(error)")
            }
        }
    }
}
