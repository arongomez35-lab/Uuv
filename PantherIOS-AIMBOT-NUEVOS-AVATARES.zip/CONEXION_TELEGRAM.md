# Panther + Telegram (@OSIELITO_Bot)

La app valida las keys en: https://project--935bed60-9c9e-466d-8c52-6beb2e2d6514.lovable.app
(Info.plist → PantherAPIBaseURL)

Rutas que usa la app:
- POST /api/public/activate            { key, device_id }
- POST /api/public/patches             { key, device_id }
- POST /api/public/patches/{id}/download

Las keys se crean en el bot de Telegram:
- /start  (la primera persona que lo envía queda como dueño)
- /key 30 5   → 5 keys de 30 días (el tiempo empieza al activarlas)
- /key perm   → key permanente
- /keyadmin   → key de administrador
- /info KEY · /reset KEY · /revocar KEY · /borrar KEY · /stats
- Enviar un archivo .3105 con el texto "Nombre | versión | categoría" lo publica en el catálogo.

Cada key se vincula al primer iPhone que la activa. Usa /reset KEY para cambiarla de dispositivo.
Debes recompilar la app (GitHub Actions / Xcode) para que use esta dirección.
